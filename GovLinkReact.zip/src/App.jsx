
import { useState } from "react";
import { motion } from "framer-motion";
import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";

function Home() {
  return (
    <motion.div
      className="p-10 text-center"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 1 }}
    >
      <h1 className="text-4xl font-bold text-blue-800">Welcome to GovLink</h1>
      <p className="mt-4 text-lg text-gray-600">Smarter governance powered by AI</p>
      <img
        src="https://i.ibb.co/LC92b9K/govlink-logo.png"
        alt="GovLink Logo"
        className="mx-auto mt-6 w-40"
      />
      <div className="mt-10 grid gap-6 md:grid-cols-3">
        <Feature title="Scheme Finder" desc="Get the right scheme for your needs." />
        <Feature title="Tax Calculator" desc="Know how much tax you owe." />
        <Feature title="GovTech" desc="AI-powered matching and updates." />
      </div>
    </motion.div>
  );
}

function Feature({ title, desc }) {
  return (
    <motion.div
      className="rounded-2xl bg-white p-6 shadow-md hover:shadow-lg"
      whileHover={{ scale: 1.05 }}
    >
      <h2 className="text-xl font-semibold text-blue-700">{title}</h2>
      <p className="mt-2 text-gray-500">{desc}</p>
    </motion.div>
  );
}

function NavBar() {
  return (
    <header className="flex items-center justify-between bg-blue-900 px-6 py-4 text-white">
      <h1 className="text-xl font-bold">GovLink</h1>
      <nav className="space-x-4">
        <Link to="/" className="hover:underline">
          Home
        </Link>
        <Link to="/scheme-finder" className="hover:underline">
          Scheme Finder
        </Link>
        <Link to="/tax-calculator" className="hover:underline">
          Tax Calculator
        </Link>
      </nav>
    </header>
  );
}

function Footer() {
  return (
    <footer className="mt-10 bg-blue-900 p-6 text-center text-white">
      <p>&copy; 2025 GovLink | <Link to="/about">About Us</Link> | <Link to="/contact">Contact Us</Link> | <Link to="/feedback">Feedback</Link></p>
    </footer>
  );
}

function SchemeFinder() {
  return <div className="p-10">Scheme Finder (To be implemented)</div>;
}

function TaxCalculator() {
  return <div className="p-10">Tax Calculator (To be implemented)</div>;
}

function AboutUs() {
  return <div className="p-10">About Us - Created by Nishchhal Agarwal</div>;
}

function ContactUs() {
  return <div className="p-10">Contact Us - contact@govlink.in</div>;
}

function Feedback() {
  return <div className="p-10">Feedback Form (Coming soon)</div>;
}

export default function App() {
  return (
    <Router>
      <NavBar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/scheme-finder" element={<SchemeFinder />} />
        <Route path="/tax-calculator" element={<TaxCalculator />} />
        <Route path="/about" element={<AboutUs />} />
        <Route path="/contact" element={<ContactUs />} />
        <Route path="/feedback" element={<Feedback />} />
      </Routes>
      <Footer />
    </Router>
  );
}
